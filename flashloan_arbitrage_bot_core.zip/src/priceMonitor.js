const ethers = require('ethers');
const axios = require('axios');

// Configuration
const config = {
  networks: {
    arbitrum: {
      rpcUrl: 'https://arb1.arbitrum.io/rpc',
      exchanges: {
        uniswap: {
          factoryAddress: '0x1F98431c8aD98523631AE4a59f267346ea31F984',
          routerAddress: '0xE592427A0AEce92De3Edee1F18E0157C05861564'
        },
        sushi: {
          factoryAddress: '0xc35DADB65012eC5796536bD9864eD8773aBc74C4',
          routerAddress: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506'
        }
      }
    },
    optimism: {
      rpcUrl: 'https://mainnet.optimism.io',
      exchanges: {
        uniswap: {
          factoryAddress: '0x1F98431c8aD98523631AE4a59f267346ea31F984',
          routerAddress: '0xE592427A0AEce92De3Edee1F18E0157C05861564'
        },
        velodrome: {
          factoryAddress: '0x25CbdDb98b35ab1FF77413456B31EC81A6B6B746',
          routerAddress: '0xa132DAB612dB5cB9fC9Ac426A0Cc215A3423F9c9'
        }
      }
    }
  },
  tokenPairs: [
    {
      symbol: 'ETH/USDC',
      tokens: {
        token0: {
          symbol: 'WETH',
          addresses: {
            arbitrum: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
            optimism: '0x4200000000000000000000000000000000000006'
          }
        },
        token1: {
          symbol: 'USDC',
          addresses: {
            arbitrum: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
            optimism: '0x7F5c764cBc14f9669B88837ca1490cCa17c31607'
          }
        }
      }
    },
    {
      symbol: 'WBTC/USDC',
      tokens: {
        token0: {
          symbol: 'WBTC',
          addresses: {
            arbitrum: '0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f',
            optimism: '0x68f180fcCe6836688e9084f035309E29Bf0A2095'
          }
        },
        token1: {
          symbol: 'USDC',
          addresses: {
            arbitrum: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
            optimism: '0x7F5c764cBc14f9669B88837ca1490cCa17c31607'
          }
        }
      }
    },
    {
      symbol: 'ARB/USDC',
      tokens: {
        token0: {
          symbol: 'ARB',
          addresses: {
            arbitrum: '0x912CE59144191C1204E64559FE8253a0e49E6548',
            optimism: null // Not available on Optimism
          }
        },
        token1: {
          symbol: 'USDC',
          addresses: {
            arbitrum: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
            optimism: '0x7F5c764cBc14f9669B88837ca1490cCa17c31607'
          }
        }
      }
    },
    {
      symbol: 'OP/USDC',
      tokens: {
        token0: {
          symbol: 'OP',
          addresses: {
            arbitrum: null, // Not available on Arbitrum
            optimism: '0x4200000000000000000000000000000000000042'
          }
        },
        token1: {
          symbol: 'USDC',
          addresses: {
            arbitrum: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
            optimism: '0x7F5c764cBc14f9669B88837ca1490cCa17c31607'
          }
        }
      }
    }
  ],
  // Profit recipient address - where all profits will be sent
  profitRecipient: '0x0dA75134705699b34fDC1eFb5821C904265dda62',
  // Minimum profit threshold (in percentage, e.g., 0.5 = 0.5%)
  minProfitThreshold: 0.5,
  // Price refresh interval in milliseconds
  refreshInterval: 30000
};

// ABI for ERC20 token
const erc20Abi = [
  'function balanceOf(address owner) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
  'function name() view returns (string)'
];

// ABI for Uniswap V3 Pool
const uniswapV3PoolAbi = [
  'function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)'
];

// ABI for Uniswap V2 Pair
const uniswapV2PairAbi = [
  'function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)'
];

// Initialize providers
const providers = {
  arbitrum: new ethers.providers.JsonRpcProvider(config.networks.arbitrum.rpcUrl),
  optimism: new ethers.providers.JsonRpcProvider(config.networks.optimism.rpcUrl)
};

/**
 * Price Monitoring Module
 * Monitors token prices across different exchanges on Arbitrum and Optimism
 */
class PriceMonitor {
  constructor() {
    this.prices = {};
    this.opportunities = [];
  }

  /**
   * Start monitoring prices
   */
  async start() {
    console.log('Starting price monitoring...');
    
    // Initial price fetch
    await this.fetchAllPrices();
    
    // Set up interval for continuous monitoring
    setInterval(async () => {
      await this.fetchAllPrices();
      this.detectArbitrageOpportunities();
    }, config.refreshInterval);
  }

  /**
   * Fetch prices for all configured token pairs across all exchanges
   */
  async fetchAllPrices() {
    console.log('Fetching prices...');
    
    for (const pair of config.tokenPairs) {
      // Skip pairs where tokens don't exist on both networks
      if (!this.isPairAvailableOnBothNetworks(pair)) {
        continue;
      }
      
      // Fetch prices for this pair on all exchanges
      await this.fetchPricesForPair(pair);
    }
    
    console.log('Current prices:', JSON.stringify(this.prices, null, 2));
  }

  /**
   * Check if a token pair is available on both networks
   */
  isPairAvailableOnBothNetworks(pair) {
    const { token0, token1 } = pair.tokens;
    
    // Check if tokens exist on both networks
    const token0Available = token0.addresses.arbitrum && token0.addresses.optimism;
    const token1Available = token1.addresses.arbitrum && token1.addresses.optimism;
    
    return token0Available && token1Available;
  }

  /**
   * Fetch prices for a specific token pair across all exchanges
   */
  async fetchPricesForPair(pair) {
    const { symbol, tokens } = pair;
    const { token0, token1 } = tokens;
    
    if (!this.prices[symbol]) {
      this.prices[symbol] = {};
    }
    
    // Fetch prices on Arbitrum exchanges
    for (const [exchangeName, exchangeInfo] of Object.entries(config.networks.arbitrum.exchanges)) {
      if (token0.addresses.arbitrum && token1.addresses.arbitrum) {
        try {
          const price = await this.fetchPriceFromExchange(
            'arbitrum',
            exchangeName,
            token0.addresses.arbitrum,
            token1.addresses.arbitrum
          );
          
          this.prices[symbol][`${exchangeName} (Arbitrum)`] = price;
        } catch (error) {
          console.error(`Error fetching price for ${symbol} on ${exchangeName} (Arbitrum):`, error.message);
        }
      }
    }
    
    // Fetch prices on Optimism exchanges
    for (const [exchangeName, exchangeInfo] of Object.entries(config.networks.optimism.exchanges)) {
      if (token0.addresses.optimism && token1.addresses.optimism) {
        try {
          const price = await this.fetchPriceFromExchange(
            'optimism',
            exchangeName,
            token0.addresses.optimism,
            token1.addresses.optimism
          );
          
          this.prices[symbol][`${exchangeName} (Optimism)`] = price;
        } catch (error) {
          console.error(`Error fetching price for ${symbol} on ${exchangeName} (Optimism):`, error.message);
        }
      }
    }
    
    // Add timestamp
    this.prices[symbol].lastUpdated = new Date().toISOString();
  }

  /**
   * Fetch price from a specific exchange
   */
  async fetchPriceFromExchange(network, exchange, token0Address, token1Address) {
    // This is a simplified implementation
    // In a real-world scenario, you would:
    // 1. Get the pool/pair address for the token pair
    // 2. Call the appropriate contract methods to get reserves or price
    // 3. Calculate the price based on the reserves and token decimals
    
    // For demonstration purposes, we'll use a mock implementation
    // that simulates fetching prices with small random variations
    
    // Base prices for common pairs (in USD)
    const basePrices = {
      'WETH': 3245.67,
      'WBTC': 62345.78,
      'ARB': 1.23,
      'OP': 3.45,
      'USDC': 1.0
    };
    
    // Add a small random variation based on the exchange and network
    const randomFactor = 1 + (Math.random() * 0.02 - 0.01); // ±1% variation
    const networkFactor = network === 'arbitrum' ? 0.998 : 1.002; // Slight difference between networks
    const exchangeFactor = exchange === 'uniswap' ? 1.001 : 0.999; // Slight difference between exchanges
    
    const token0Symbol = Object.keys(config.tokenPairs.flatMap(p => [p.tokens.token0, p.tokens.token1]))
      .find(t => t.addresses && (t.addresses[network] === token0Address))?.symbol || 'UNKNOWN';
    
    const token1Symbol = Object.keys(config.tokenPairs.flatMap(p => [p.tokens.token0, p.tokens.token1]))
      .find(t => t.addresses && (t.addresses[network] === token1Address))?.symbol || 'UNKNOWN';
    
    // Calculate price (token0 in terms of token1)
    let price;
    if (token1Symbol === 'USDC') {
      // If token1 is USDC, return the price of token0 in USD
      price = basePrices[token0Symbol] * randomFactor * networkFactor * exchangeFactor;
    } else {
      // Otherwise calculate the ratio
      price = basePrices[token0Symbol] / basePrices[token1Symbol] * randomFactor * networkFactor * exchangeFactor;
    }
    
    return price;
  }

  /**
   * Detect arbitrage opportunities based on current prices
   */
  detectArbitrageOpportunities() {
    console.log('Detecting arbitrage opportunities...');
    
    this.opportunities = [];
    
    for (const [pairSymbol, pairPrices] of Object.entries(this.prices)) {
      // Skip the lastUpdated field
      if (pairSymbol === 'lastUpdated') continue;
      
      const exchanges = Object.keys(pairPrices).filter(key => key !== 'lastUpdated');
      
      // Need at least 2 exchanges to compare
      if (exchanges.length < 2) continue;
      
      // Find the exchange with the lowest and highest prices
      let lowestPrice = Infinity;
      let highestPrice = -Infinity;
      let lowestExchange = '';
      let highestExchange = '';
      
      for (const exchange of exchanges) {
        const price = pairPrices[exchange];
        
        if (price < lowestPrice) {
          lowestPrice = price;
          lowestExchange = exchange;
        }
        
        if (price > highestPrice) {
          highestPrice = price;
          highestExchange = exchange;
        }
      }
      
      // Calculate price difference and percentage
      const priceDifference = highestPrice - lowestPrice;
      const percentageDifference = (priceDifference / lowestPrice) * 100;
      
      // Check if the opportunity meets the minimum profit threshold
      if (percentageDifference >= config.minProfitThreshold) {
        // Estimate gas costs (this would be more complex in a real implementation)
        const estimatedGasCost = 0.005 * lowestPrice; // Simplified estimate
        
        // Calculate potential profit for a trade of 1 unit
        const grossProfit = priceDifference;
        const netProfit = grossProfit - estimatedGasCost;
        
        // Only consider profitable opportunities after gas costs
        if (netProfit > 0) {
          const opportunity = {
            id: this.opportunities.length + 1,
            tokenPair: pairSymbol,
            buyExchange: lowestExchange,
            buyPrice: lowestPrice,
            sellExchange: highestExchange,
            sellPrice: highestPrice,
            priceDifference,
            percentageDifference,
            estimatedProfit: grossProfit,
            estimatedGasCost,
            netProfit,
            profitability: this.calculateProfitability(percentageDifference),
            timestamp: new Date().toISOString(),
            status: 'Active'
          };
          
          this.opportunities.push(opportunity);
          
          console.log(`Arbitrage opportunity found for ${pairSymbol}:`);
          console.log(`  Buy from ${lowestExchange} at ${lowestPrice}`);
          console.log(`  Sell to ${highestExchange} at ${highestPrice}`);
          console.log(`  Profit: ${netProfit.toFixed(4)} (${percentageDifference.toFixed(2)}%)`);
        }
      }
    }
    
    return this.opportunities;
  }

  /**
   * Calculate profitability category based on percentage difference
   */
  calculateProfitability(percentageDifference) {
    if (percentageDifference >= 0.8) {
      return 'High';
    } else if (percentageDifference >= 0.3) {
      return 'Medium';
    } else {
      return 'Low';
    }
  }

  /**
   * Get current prices
   */
  getPrices() {
    return this.prices;
  }

  /**
   * Get current arbitrage opportunities
   */
  getOpportunities() {
    return this.opportunities;
  }
}

// Export the PriceMonitor class
module.exports = {
  PriceMonitor,
  config
};

// If this file is run directly, start the price monitor
if (require.main === module) {
  const monitor = new PriceMonitor();
  monitor.start().catch(console.error);
}
