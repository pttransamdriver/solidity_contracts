# Flashloan Research Notes

## Flashloan Concepts
- A flash loan is a type of uncollateralized loan that lets a user borrow assets with no upfront collateral as long as the borrowed assets are paid back within the same blockchain transaction.
- If the borrower does not pay back the loan in the same transaction, then the entire transaction is reverted.
- Flash loans enable users to borrow assets from an on-chain liquidity pool with no upfront collateral as long as the borrowed amount of liquidity, plus any fee, is returned to the pool within the same transaction.

## Common Use Cases
1. **Arbitrage**: Harnessing large amounts of capital to fill inefficiencies in the market where an asset has differing exchange rates on different markets.
2. **Liquidations**: Helping ensure that undercollateralized loans are liquidated on time and the underlying protocol remains solvent.
3. **Collateral Swaps**: Closing loans with borrowed funds to immediately open a new loan with a different asset as collateral.
4. **Creating Leveraged Positions**: Simplifying the process of creating a leveraged position.

## Flashloan Providers on Arbitrum and Optimism

### Balancer V2
- **Fee**: 0.0% (zero fee)
- **Contract Interface**: Similar to Aave flashloan and easy to use
- **Vault Contract Address**: 0xBA12222222228d8Ba445958a75a0704d566BF2C8
- **Networks**: Available on both Arbitrum and Optimism
- **Benefits**: 
  - No flashloan fee
  - Able to borrow a huge amount of tokens
  - Many kinds of tokens available
  - High liquidity

### Aave V3
- **Fee**: 0.05%
- **Networks**: Available on Ethereum, Arbitrum, and Optimism
- **Features**: Requires FLASH_BORROWER_ROLE for contracts to use flashloans

## Implementation Details

### Balancer V2 Implementation
To implement a flashloan with Balancer V2:

1. Create a contract that implements the `IFlashLoanRecipient` interface
2. Implement the `receiveFlashLoan` function to handle the borrowed funds
3. Use the Vault contract to call the `flashLoan` function

```solidity
pragma solidity ^0.7.0;

import {IVault} from "@balancer-labs/v2-interfaces/contracts/vault/IVault.sol";
import {IFlashLoanRecipient} from "@balancer-labs/v2-interfaces/contracts/vault/IFlashLoanRecipient.sol";
import {IERC20} from "@balancer-labs/v2-interfaces/contracts/solidity-utils/openzeppelin/IERC20.sol";

contract FlashLoanRecipient is IFlashLoanRecipient {
    IVault private constant vault = IVault(0xBA12222222228d8Ba445958a75a0704d566BF2C8);

    function makeFlashLoan(IERC20[] memory tokens, uint256[] memory amounts, bytes memory userData) external {
        vault.flashLoan(this, tokens, amounts, userData);
    }

    function receiveFlashLoan(
        IERC20[] memory tokens,
        uint256[] memory amounts,
        uint256[] memory feeAmounts,
        bytes memory userData
    ) external override {
        require(msg.sender == address(vault));
        
        // This contract now has the funds requested.
        // Your logic goes here...
        
        // Return loan
        for (uint256 i = 0; i < tokens.length; i++) {
            tokens[i].transfer(address(vault), amounts[i] + feeAmounts[i]);
        }
    }
}
```

## Security Considerations
- Flash loans can be used for price oracle attacks if protocols rely on a single DEX for price feeds
- Protocols should use decentralized oracle solutions with proper market coverage to prevent manipulation
- Smart contract developers should understand the risks associated with flash loans to build more robust applications
