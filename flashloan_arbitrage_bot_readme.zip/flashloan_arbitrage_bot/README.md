# Flashloan Arbitrage Bot - Setup and Usage Instructions

This document provides instructions for setting up and using the Flashloan Arbitrage Bot that monitors price disparities between exchanges on Arbitrum and Optimism networks and executes profitable trades using flashloans.

## Project Structure

The project is divided into two main components:

1. **Core Components** (`flashloan_arbitrage_bot_core.zip`):
   - Smart contracts for flashloan arbitrage
   - Price monitoring module
   - Arbitrage execution module
   - Documentation and research notes

2. **Web Interface** (`flashloan_arbitrage_bot_website.zip`):
   - Next.js dashboard application
   - Price monitoring interface
   - Arbitrage opportunities tracker
   - Trade simulator
   - Settings management

## Setup Instructions

### Core Components Setup

1. Extract `flashloan_arbitrage_bot_core.zip` to your project directory
2. Install dependencies:
   ```bash
   npm install ethers axios
   ```
3. Configure your environment:
   - Update contract addresses in `src/arbitrageExecutor.js`
   - Set your private key securely (preferably via environment variables)

### Smart Contract Deployment

1. Install Hardhat or Truffle for contract deployment
2. Deploy the `FlashloanArbitrageBot.sol` contract to Arbitrum and/or Optimism
3. Note that the contract is configured to send all profits to: `0x0dA75134705699b34fDC1eFb5821C904265dda62`

### Web Interface Setup

1. Extract `flashloan_arbitrage_bot_website.zip` to your project directory
2. Navigate to the extracted directory
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5. Access the dashboard at `http://localhost:3000`

## Usage Instructions

### Running the Bot

1. Start the price monitoring module:
   ```bash
   node src/priceMonitor.js
   ```

2. Start the arbitrage executor (in a separate terminal):
   ```bash
   PRIVATE_KEY=your_private_key node src/arbitrageExecutor.js
   ```

### Using the Dashboard

The dashboard provides several features:

1. **Price Monitor**: View real-time token prices across different exchanges
2. **Opportunities**: Track potential arbitrage opportunities
3. **Simulator**: Test potential trades without executing them
4. **Flashloans**: View available flashloan contracts
5. **History**: View past trades and their outcomes
6. **Settings**: Configure bot parameters

## Important Notes

- **Profit Distribution**: All profits from successful arbitrage trades are automatically sent to `0x0dA75134705699b34fDC1eFb5821C904265dda62` as requested
- **Gas Costs**: The bot estimates gas costs and only executes trades that are profitable after accounting for fees
- **Security**: Never expose your private key in code; use environment variables
- **Testing**: Always test with small amounts before running with significant capital

## Customization

- Modify `config` in `priceMonitor.js` to add/remove token pairs or exchanges
- Adjust profit thresholds in the settings page or directly in the code
- Update the smart contract if you need to change the profit distribution mechanism

## Troubleshooting

- If the bot fails to detect opportunities, check that the price feeds are working correctly
- If transactions fail, verify that you have sufficient funds for gas
- For website issues, check the browser console for errors

## License

This project is provided for educational purposes. Use at your own risk.
